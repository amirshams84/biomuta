
<?php



//echo "hello I  am here ";


mysql_connect("localhost", "ashamsad","Navadeh12") or die(mysql_error());
mysql_select_db("biomuta") or die(mysql_error());

$query="SELECT DISTINCT(Gene_name) FROM cancer ORDER BY (Gene_name) ASC";

// Get all the data from the "example" table
$result = mysql_query($query) 
or die(mysql_error());  

$gene=array();

$i=0;
// keeps getting the next row until there are no more to get
while($row = mysql_fetch_array( $result )) {
	
	$gene[$i]=$row['Gene_name'];
	
	++$i;
	
} 

//print_r($gene);
////////////////////////////////
//Cancer TYpe selection
$query="SELECT DISTINCT(CancerType) FROM cancer ORDER BY (CancerType) ASC";

// Get all the data from the "example" table
$result = mysql_query($query) 
or die(mysql_error());  

$cancer=array();

$i=0;
// keeps getting the next row until there are no more to get
while($row = mysql_fetch_array( $result )) {
	
	$cancer[$i]=$row['CancerType'];
	
	++$i;
	
} 
///////////////////////////
//Protein Sleection
$query="SELECT DISTINCT(Protein_ID) FROM cancer ORDER BY (Protein_ID) ASC";

// Get all the data from the "example" table
$result = mysql_query($query) 
or die(mysql_error());  

$protein=array();

$i=0;
// keeps getting the next row until there are no more to get
while($row = mysql_fetch_array( $result )) {
	
	$protein[$i]=$row['Protein_ID'];
	
	++$i;
	
} 
///////////////////////////
//Accession Number
$query="SELECT DISTINCT(Accession_Number) FROM cancer ORDER BY (Accession_Number) ASC";

// Get all the data from the "example" table
$result = mysql_query($query) 
or die(mysql_error());  

$acc=array();

$i=0;
// keeps getting the next row until there are no more to get
while($row = mysql_fetch_array( $result )) {
	
	$acc[$i]=$row['Accession_Number'];
	
	++$i;
	
} 


?>




<!doctype html>
 
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Biomuta v1.0</title>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css" />
  <script language="JavaScript1.1" src="index_files/qpride.js"> </script>
	<script language="JavaScript1.1" src="index_files/basic.js"> </script>
	<link rel="stylesheet" href="index_files/styles.css" type="text/css">
	<link rel="stylesheet" href="index_files/menu.css" type="text/css">

  
  <div id="top_menu">
             <a id="logo" href="http://hive.biochemistry.gwu.edu/"><img src="index_files/hive-small-brand.png" border="0" height="35"></a>
			<ul class="menu_panel">
				<li class="retrieve-panel">
									
				</li>
				<li class="panel"><a class="menuitem" id="about" href="http://hive.biochemistry.gwu.edu/about.php">ABOUT</a></li>
				<li class="panel"><a class="menuitem" id="tools" href="http://hive.biochemistry.gwu.edu/tools.php">TOOLS</a></li>
				<li class="panel"><a class="menuitem" id="data" href="http://hive.biochemistry.gwu.edu/data.php">DATA</a></li>
				
				<li class="panel"><a class="menuitem" id="people" href="http://hive.biochemistry.gwu.edu/people.php">PEOPLE</a></li>
				<li class="panel"><a class="menuitem" id="contact" href="http://hive.biochemistry.gwu.edu/contact.php">CONTACT</a></li>
				

            </ul>

		</div>
  
  
  
  
  
  
  
  <style>
  .custom-combobox {
    position: relative;
    display: inline-block;
  }
  .custom-combobox-toggle {
    position: absolute;
    top: 0;
    bottom: 0;
    margin-left: -1px;
    padding: 0;
    /* support: IE7 */
    *height: 1.7em;
    *top: 0.1em;
  }
  .custom-combobox-input {
    margin: 0;
    padding: 0.3em;
  }
  </style>
  
  
  
  
  
  
  
  <script>
  (function( $ ) {
    $.widget( "custom.combobox", {
      _create: function() {
        this.wrapper = $( "<span>" )
          .addClass( "custom-combobox" )
          .insertAfter( this.element );
 
        this.element.hide();
        this._createAutocomplete();
        this._createShowAllButton();
      },
 
      _createAutocomplete: function() {
        var selected = this.element.children( ":selected" ),
          value = selected.val() ? selected.text() : "";
 
        this.input = $( "<input>" )
          .appendTo( this.wrapper )
          .val( value )
          .attr( "title", "" )
          .addClass( "custom-combobox-input ui-widget ui-widget-content ui-state-default ui-corner-left" )
          .autocomplete({
            delay: 0,
            minLength: 0,
            source: $.proxy( this, "_source" )
          })
          .tooltip({
            tooltipClass: "ui-state-highlight"
          });
 
        this._on( this.input, {
          autocompleteselect: function( event, ui ) {
            ui.item.option.selected = true;
            this._trigger( "select", event, {
              item: ui.item.option
            });
          },
 
          autocompletechange: "_removeIfInvalid"
        });
      },
 
      _createShowAllButton: function() {
        var input = this.input,
          wasOpen = false;
 
        $( "<a>" )
          .attr( "tabIndex", -1 )
          .attr( "title", "Show All Items" )
          .tooltip()
          .appendTo( this.wrapper )
          .button({
            icons: {
              primary: "ui-icon-triangle-1-s"
            },
            text: false
          })
          .removeClass( "ui-corner-all" )
          .addClass( "custom-combobox-toggle ui-corner-right" )
          .mousedown(function() {
            wasOpen = input.autocomplete( "widget" ).is( ":visible" );
          })
          .click(function() {
            input.focus();
 
            // Close if already visible
            if ( wasOpen ) {
              return;
            }
 
            // Pass empty string as value to search for, displaying all results
            input.autocomplete( "search", "" );
          });
      },
 
      _source: function( request, response ) {
        var matcher = new RegExp( $.ui.autocomplete.escapeRegex(request.term), "i" );
        response( this.element.children( "option" ).map(function() {
          var text = $( this ).text();
          if ( this.value && ( !request.term || matcher.test(text) ) )
            return {
              label: text,
              value: text,
              option: this
            };
        }) );
      },
 
      _removeIfInvalid: function( event, ui ) {
 
        // Selected an item, nothing to do
        if ( ui.item ) {
          return;
        }
 
        // Search for a match (case-insensitive)
        var value = this.input.val(),
          valueLowerCase = value.toLowerCase(),
          valid = false;
        this.element.children( "option" ).each(function() {
          if ( $( this ).text().toLowerCase() === valueLowerCase ) {
            this.selected = valid = true;
            return false;
          }
        });
 
        // Found a match, nothing to do
        if ( valid ) {
          return;
        }
 
        // Remove invalid value
        this.input
          .val( "" )
          .attr( "title", value + " didn't match any item" )
          .tooltip( "open" );
        this.element.val( "" );
        this._delay(function() {
          this.input.tooltip( "close" ).attr( "title", "" );
        }, 2500 );
        this.input.data( "ui-autocomplete" ).term = "";
      },
 
      _destroy: function() {
        this.wrapper.remove();
        this.element.show();
      }
    });
  })( jQuery );
 
  $(function() {
    $( "#combobox1" ).combobox();
    $( "#toggle" ).click(function() {
      $( "#combobox" ).toggle();
    });
  });
  $(function() {
    $( "#combobox2" ).combobox();
    $( "#toggle" ).click(function() {
      $( "#combobox" ).toggle();
    });
  });
  $(function() {
    $( "#combobox3" ).combobox();
    $( "#toggle" ).click(function() {
      $( "#combobox" ).toggle();
    });
  });
  </script>
  
  
  
  
  
  

</head>















    





	
	








<div id="body_container">
<div id="top_template">
	<h2 id="cgiLocation">Biomuta v1.0</h2>
	<div id="top_image">
</div>



 Cancer Biomarker-Variation Database
	


<form name="choose" method = "POST" action = result.php>
	<div id="tool-parameter-holder" class="QP_tbl">
    	<b>
					
    	</b>
    	
		<div id="inner-container">
		<table>
			<tbody><tr>
				<div >
  <label font: normal 18px courier >Select Gene name:  </label>
  
  <select id="combobox1" name="Gene">
    <option value="">Select one...</option>
    <?php
    for($i=0; $i<sizeof($gene);$i++){
    //<option value="ActionScript">ActionScript</option>
    echo "<option value=".$gene[$i].">".$gene[$i]."</option>";
    }
    
    ?>
  </select>
  
</div>
			</tr>
		</tbody></table>
		</div>
		
		<input name="reset-button" type="reset">
		<input id="submission" name="c" value="Submit" onclick="message()" type="submit">
	</div>
</form>



<p><b>Note: </b><i>...</i></p>

























<form name="spc">
<div style="position:absolute; visibility:hidden; " id="floatDiv"></div>
</form>
<div id="bottom-container">
<ul class="bottom_menu">
	<li class="bottom_panel">©2013&nbsp;</li>
	<li class="bottom_panel">&nbsp;<a href="http://hive.biochemistry.gwu.edu/privacy.php">License &amp; Disclaimer</a>&nbsp;</li>
	<li class="bottom_panel">&nbsp;<a href="http://hive.biochemistry.gwu.edu/contact.php">Contacts</a></li>
</ul>
</div>
</div>




</div></body></html>

