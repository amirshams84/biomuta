<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>

<style>
body {
	margin:0;
	padding:40px;
	background:#00ffff;
	font:80% Arial, Helvetica, sans-serif;
	color:#303030;
	line-height:180%;
}

h1{
	font-size:180%;
	font-weight:normal;
	color:#555;
}
a{
	text-decoration:none;
	color:#0000FF;	
}
p{
	clear:both;
	margin:0;
	padding:.5em 0;
}
pre{
	display:block;
	font:100% "Courier New", Courier, monospace;
	padding:10px;
	border:1px solid #bae2f0;
	background:#e3f4f9;	
	margin:.5em 0;
	overflow:auto;
	width:800px;
}


/*  */

#tooltip{
	position:absolute;
	border:1px solid #333;
	background:#f7f5d1;
	padding:2px 5px;
	color:#333;
	display:none;
	}	

/*  */
</style>
</head>



<body>
<br />

<p>

<font size="7"  face="Georgia, Arial, Garamond">Biomuta   </font>
<font size="5"  face="Georgia, Arial, Garamond"> v1.0  </font>


<br />
<font size="3"  face="Georgia, Arial, Garamond">CANCER BIOMARKER DATABASE </font>
<br />
<br />
</p>
<br />
<br  />



<?php










if(isset($_GET['gene']))$x=$_GET['gene'];


// Make a MySQL Connection
mysql_connect("localhost", "ashamsad","Navadeh12") or die(mysql_error());
mysql_select_db("biomuta") or die(mysql_error());
$query="SELECT * FROM cancer WHERE Gene_name='".$x."'";

// Get all the data from the "example" table
$result = mysql_query($query) 
or die(mysql_error());  

echo "<table border='1'>";
echo "<tr><th>Accession_Number</th>,
 <th>Protein_ID</th>,
 <th>Gene_name</th>,
 <th>Chromosome</th>,
 <th>Genome_position</th>,
 <th>Position_N</th>,
 <th>WildType_N</th>,
 <th>Variant_N</th>,
 <th>Position_A</th>,
 <th>WildType_A</th>,
 <th>Variant_A</th>,
 <th>CancerType</th>,
 <th>Publication_PMID</th>,
 <th>Publication_Count</th>,
 <th>State</th></tr>";

// keeps getting the next row until there are no more to get
while($row = mysql_fetch_array( $result )) {
	// Print out the contents of each row into a table
	echo "<tr><td align=".'center'.">";
	if(strpbrk($row['Accession_Number'],'ENST'))echo "<a target=".'_blank'." href=".'http://useast.ensembl.org/Homo_sapiens/Transcript/Transcript?t='.$row['Accession_Number'].''."     >";
	elseif(strpbrk($row['Accession_Number'],'XM'))echo "<a target=".'_blank'." href=".'http://www.ncbi.nlm.nih.gov/nuccore/'.$row['Accession_Number'].''."     >";
	else echo "<a target=".'_blank'." href=".'http://www.ncbi.nlm.nih.gov/gene/?term='.$row['Accession_Number'].''."     >";
	echo $row['Accession_Number'];
	echo '</a>';
	echo "<td align=".'center'.">";
	echo "<a target=".'_blank'." href=".'http://www.uniprot.org/uniprot/'.$row['Protein_ID'].''."     >"; 
	echo $row['Protein_ID'];
	echo '</a>';
	echo "</td>";
	echo "<td align=".'center'.">"; 
	echo $row['Gene_name'];
	echo "</td><td align=".'center'.">"; 
	echo $row['Chromosome'];
	echo "</td>";
	echo "<td align=".'center'.">";
	echo "<a target=".'_blank'." href=".'http://genome.ucsc.edu/cgi-bin/hgTracks?org=human&position=chr'.$row['Chromosome'].':'.$row['Genome_position']."     >";  
	echo $row['Genome_position'];
	echo '</a>';
	echo "</td><td align=".'center'.">"; 
	echo $row['Position_N'];
	echo "</td>";
	echo "<td align=".'center'.">"; 
	echo $row['WildType_N'];
	echo "</td><td align=".'center'.">"; 
	echo $row['Variant_N'];
	echo "</td>";
	echo "<td align=".'center'.">"; 
	echo $row['Position_A'];
	echo "</td><td align=".'center'.">"; 
	echo $row['WildType_A'];
	echo "</td>";
	echo "<td align=".'center'.">"; 
	echo $row['Variant_A'];
	echo "</td><td align=".'center'.">";
	echo "<a target=".'_blank'." href=".'https://tcga-data.nci.nih.gov/tcga/'.$row['CancerType'].''."     >"; 
	echo $row['CancerType'];
	echo '</a>';
	echo "</td>";
	echo "<td align=".'center'.">";
	echo "<a target=".'_blank'." href=".'http://www.ncbi.nlm.nih.gov/pubmed/?term='.$row['Publication_PMID'].''."     >"; 
	echo $row['Publication_PMID'];
	echo '</a>';
	echo "</td>";
	echo "<td align=".'center'.">"; 
	echo $row['Publication_Count'];
	echo "</td>";
	echo "<td align=".'center'.">";
	echo $row['State'];
	echo "</td></tr>"; 
} 

echo "</table>";


?>
<input action="action" type="button" value="Back" onclick="history.go(-1);" />